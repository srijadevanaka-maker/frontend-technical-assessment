import React from "react";
import UI from "./UI";

function App() {
  return (
    <div>
      <UI />
    </div>
  );
}

export default App;