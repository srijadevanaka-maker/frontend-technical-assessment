import React from "react";
import BaseNode from "./BaseNode";

const LLMNode = () => {
  return (
    <BaseNode title="LLM Node">
      <p>LLM processing</p>
    </BaseNode>
  );
};

export default LLMNode;