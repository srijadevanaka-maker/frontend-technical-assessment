import React from "react";

const BaseNode = ({ title, children }) => {
  return (
    <div style={{
      border: "1px solid #ccc",
      padding: "10px",
      borderRadius: "10px",
      background: "#f9fafb",
      minWidth: "150px",
      boxShadow: "0 2px 8px rgba(0,0,0,0.1)"
    }}>
      <h4>{title}</h4>
      {children}
    </div>
  );
};

export default BaseNode;