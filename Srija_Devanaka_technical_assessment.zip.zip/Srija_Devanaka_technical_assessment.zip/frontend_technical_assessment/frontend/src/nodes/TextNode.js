import React, { useState } from "react";
import BaseNode from "./BaseNode";

const TextNode = () => {
  const [text, setText] = useState("");

  // Detect variables like {{name}}
  const variables = text.match(/{{(.*?)}}/g) || [];

  return (
    <BaseNode title="Text Node">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type something like {{name}}"
        style={{
          width: "100%",
          minHeight: "50px",
          resize: "none"
        }}
      />

      <div>
        <p><b>Variables:</b></p>
        {variables.map((v, index) => (
          <p key={index}>{v}</p>
        ))}
      </div>
    </BaseNode>
  );
};

export default TextNode;