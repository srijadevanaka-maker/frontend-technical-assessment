import React from "react";
import BaseNode from "./BaseNode";

const FilterNode = () => {
  return (
    <BaseNode title="Filter Node">
      <p>Filter data</p>
    </BaseNode>
  );
};

export default FilterNode;