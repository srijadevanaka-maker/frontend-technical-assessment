import React from "react";
import BaseNode from "./BaseNode";

const InputNode = () => {
  return (
    <BaseNode title="Input Node">
      <p>Input content</p>
    </BaseNode>
  );
};

export default InputNode;