import React from "react";
import BaseNode from "./BaseNode";

const CustomNode = () => {
  return (
    <BaseNode title="Custom Node">
      <p>Custom logic here</p>
    </BaseNode>
  );
};

export default CustomNode;