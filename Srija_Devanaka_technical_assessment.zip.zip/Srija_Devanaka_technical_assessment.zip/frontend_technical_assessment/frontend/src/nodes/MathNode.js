import React from "react";
import BaseNode from "./BaseNode";

const MathNode = () => {
  return (
    <BaseNode title="Math Node">
      <p>Perform calculations</p>
    </BaseNode>
  );
};

export default MathNode;