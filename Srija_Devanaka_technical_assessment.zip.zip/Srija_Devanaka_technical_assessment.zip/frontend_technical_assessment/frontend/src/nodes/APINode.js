import React from "react";
import BaseNode from "./BaseNode";

const APINode = () => {
  return (
    <BaseNode title="API Node">
      <p>API request node</p>
    </BaseNode>
  );
};

export default APINode;