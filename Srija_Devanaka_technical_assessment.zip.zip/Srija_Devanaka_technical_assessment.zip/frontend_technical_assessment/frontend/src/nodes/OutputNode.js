import React from "react";
import BaseNode from "./BaseNode";

const OutputNode = () => {
  return (
    <BaseNode title="Output Node">
      <p>Output content</p>
    </BaseNode>
  );
};

export default OutputNode;