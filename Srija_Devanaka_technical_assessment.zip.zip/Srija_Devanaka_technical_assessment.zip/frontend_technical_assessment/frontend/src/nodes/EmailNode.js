import React from "react";
import BaseNode from "./BaseNode";

const EmailNode = () => {
  return (
    <BaseNode title="Email Node">
      <p>Send email functionality</p>
    </BaseNode>
  );
};

export default EmailNode;