export const submitPipeline = async (nodes, edges) => {
  try {
    const response = await fetch("http://127.0.0.1:8000/pipelines/parse", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        nodes: nodes,
        edges: edges,
      }),
    });

    const result = await response.json();

    alert(
      "Nodes: " + result.num_nodes +
      "\nEdges: " + result.num_edges +
      "\nIs DAG: " + result.is_dag
    );
  } catch (error) {
    console.error("Error:", error);
    alert("Error connecting to backend");
  }
};