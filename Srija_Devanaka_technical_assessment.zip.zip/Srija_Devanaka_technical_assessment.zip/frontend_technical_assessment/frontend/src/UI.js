import React, { useState } from "react";
import { submitPipeline } from "./submit";

function UI() {
  const [nodes, setNodes] = useState([
    { id: 1 },
    { id: 2 }
  ]);

  const [edges, setEdges] = useState([
    [1, 2]
  ]);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Pipeline UI</h2>

      <button onClick={() => submitPipeline(nodes, edges)}>
        Submit Pipeline
      </button>
    </div>
  );
}

export default UI;